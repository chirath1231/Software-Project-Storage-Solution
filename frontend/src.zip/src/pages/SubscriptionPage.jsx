import React, { useEffect, useState } from "react";

export default function SubscriptionPage() {
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState(null);

  // Load subscriptions and user email
  useEffect(() => {
    const email = localStorage.getItem("userEmail");
    setUserEmail(email);

    fetch("http://127.0.0.1:8000/api/subscriptions/")
      .then((res) => res.json())
      .then((data) => setSubscriptions(data))
      .catch((err) => console.error("Error fetching subscriptions:", err))
      .finally(() => setLoading(false));
  }, []);

  // Load PayHere script
  const loadPayHereScript = () => {
    return new Promise((resolve, reject) => {
      if (document.getElementById("payhere-script")) return resolve();

      const script = document.createElement("script");
      script.src = "https://www.payhere.lk/lib/payhere.js";
      script.id = "payhere-script";
      script.onload = resolve;
      script.onerror = () => reject("PayHere script failed to load");
      document.body.appendChild(script);
    });
  };

  // Handle subscription purchase
  const handleSubscribe = async (sub) => {
    if (!userEmail) return alert("Please login first");

    try {
      await loadPayHereScript();

      const paymentRes = await fetch(
        "http://127.0.0.1:8000/api/subscriptions/create-payment/",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            subscription_id: sub.id,
            email: userEmail,
            amount: sub.price,
            first_name: userEmail.split("@")[0],
          }),
        }
      );

      // Read response as text to detect HTML errors
      const raw = await paymentRes.text();

      if (raw.startsWith("<")) {
        console.error("Server returned HTML:", raw);
        alert("Server error. Check Django logs.");
        return;
      }

      const paymentDataJson = JSON.parse(raw);

      if (!paymentDataJson.success) {
        console.error("Backend returned error:", paymentDataJson.error);
        alert(paymentDataJson.error || "Payment creation failed");
        return;
      }

      const paymentData = paymentDataJson.paymentData;

      if (!window.payhere) return alert("PayHere script not loaded");

      // Start PayHere payment
      window.payhere.startPayment({
        sandbox: paymentData.sandbox,
        merchant_id: paymentData.merchant_id,
        return_url: paymentData.return_url,
        cancel_url: paymentData.cancel_url,
        notify_url: paymentData.notify_url,
        order_id: paymentData.order_id,
        items: sub.name,
        amount: parseFloat(paymentData.amount),
        currency: paymentData.currency,
        first_name: paymentData.first_name,
        last_name: paymentData.last_name,
        email: paymentData.email,
        phone: paymentData.phone,
        address: paymentData.address,
        city: paymentData.city,
        country: paymentData.country,
        custom_1: paymentData.custom_1,
        hash: paymentData.hash,
      });
    } catch (err) {
      console.error("Payment error:", err);
      alert(err);
    }
  };

  if (loading) return <h2 style={{ padding: "20px" }}>Loading...</h2>;

  return (
    <div style={{ padding: "30px" }}>
      <h1 style={{ fontSize: "32px", marginBottom: "20px" }}>
        Available Subscriptions
      </h1>

      <div
        style={{
          display: "grid",
          gap: "20px",
          gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
        }}
      >
        {subscriptions.map((sub) => (
          <div
            key={sub.id}
            style={{
              border: "1px solid #ccc",
              padding: "20px",
              borderRadius: "10px",
              boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
            }}
          >
            <h2 style={{ fontSize: "24px", marginBottom: "10px" }}>
              {sub.name}
            </h2>
            <p>{sub.description}</p>
            <p
              style={{ marginTop: "15px", fontSize: "20px", fontWeight: "bold" }}
            >
              Rs. {sub.price}
            </p>

            <button
              style={{
                marginTop: "15px",
                padding: "10px 15px",
                background: "#007bff",
                color: "white",
                border: "none",
                borderRadius: "8px",
                cursor: "pointer",
              }}
              onClick={() => handleSubscribe(sub)}
            >
              Subscribe Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
